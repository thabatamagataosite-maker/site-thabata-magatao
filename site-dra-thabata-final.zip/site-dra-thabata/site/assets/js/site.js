(function () {
  'use strict';
  window.__TM_EXPORT__ = true; // site publicado: o mapa carrega na própria página
  class DCLogic { constructor() { this.props = {}; this.state = {}; } setState() {} }
  class Component extends DCLogic {
  // Galeria horizontal fixa (GSAP + ScrollTrigger).
  // componentDidMount roda na mesma fase do useLayoutEffect; mesmo assim esperamos
  // 2 frames + um pequeno atraso e conferimos as larguras antes de calcular o pin.
  componentDidMount() { this._initCookies(); this._initGallery(); this._initLocal(); this._initReviews(); this._initPay(); this._initProf(); }
  // consentimento de cookies de terceiros (LGPD): 'granted' | 'denied' | null (ainda não escolheu)
  _consent(v) {
    try { if (v) localStorage.setItem('tm-consent', v); return localStorage.getItem('tm-consent'); }
    catch (e) { if (v) this._consentMem = v; return this._consentMem || null; }
  }
  _killCookies() { if (this._cookies) { this._cookies.off(); this._cookies = null; } }
  _initCookies() {
    this._killCookies();
    const box = document.querySelector('.tm-cookie');
    if (!box) return;
    const yes = box.querySelector('.tm-cookie-yes'), no = box.querySelector('.tm-cookie-no');
    const opens = [...document.querySelectorAll('.tm-cookie-open')];
    const set = (v) => { this._consent(v); box.hidden = true; document.dispatchEvent(new CustomEvent('tm-consent', { detail: v })); };
    const onYes = () => set('granted'), onNo = () => set('denied');
    const onOpen = () => { box.hidden = false; yes.focus(); };
    if (!this._consent()) box.hidden = false;
    yes.addEventListener('click', onYes); no.addEventListener('click', onNo);
    opens.forEach((o) => o.addEventListener('click', onOpen));
    this._cookies = { box, off: () => {
      yes.removeEventListener('click', onYes); no.removeEventListener('click', onNo);
      opens.forEach((o) => o.removeEventListener('click', onOpen));
    } };
  }
  _killProf() { if (this._prof) { this._prof.off(); this._prof = null; } }
  _initProf() {
    this._killProf();
    const section = document.getElementById('profissionais');
    const track = section && section.querySelector('.tm-prof-track');
    if (!track) return;
    const dots = [...section.querySelectorAll('.tm-prof-dot')];
    const n = track.querySelectorAll('img').length;
    const cur = () => Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
    const go = (i) => track.scrollTo({ left: ((i + n) % n) * track.clientWidth, behavior: 'smooth' });
    const mark = () => { const i = cur(); dots.forEach((d, k) => d.setAttribute('aria-current', k === i ? 'true' : 'false')); };
    let raf;
    const onScroll = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(mark); };
    const onDot = (e) => { stop(); go(dots.indexOf(e.currentTarget)); };
    const onKey = (e) => { if (e.key === 'ArrowRight') { e.preventDefault(); stop(); go(cur() + 1); } else if (e.key === 'ArrowLeft') { e.preventDefault(); stop(); go(cur() - 1); } };
    // passa sozinho a cada 4 s; para de vez quando a pessoa mexe; respeita "reduzir movimento"
    let timer = null, visible = false;
    const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const tick = () => { if (visible && !document.hidden) go(cur() + 1); };
    const stop = () => { clearInterval(timer); timer = null; };
    if (!reduce && n > 1) timer = setInterval(tick, 4000);
    let io = null;
    if ('IntersectionObserver' in window) { io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; }, { threshold: 0.4 }); io.observe(track); } else visible = true;
    track.addEventListener('scroll', onScroll, { passive: true });
    track.addEventListener('pointerdown', stop);
    track.addEventListener('touchstart', stop, { passive: true });
    track.addEventListener('keydown', onKey);
    dots.forEach((d) => d.addEventListener('click', onDot));
    this._prof = { section, off: () => {
      stop(); cancelAnimationFrame(raf); if (io) io.disconnect();
      track.removeEventListener('scroll', onScroll); track.removeEventListener('pointerdown', stop);
      track.removeEventListener('touchstart', stop); track.removeEventListener('keydown', onKey);
      dots.forEach((d) => d.removeEventListener('click', onDot));
    } };
  }
  _killPay() { if (this._pay) { this._pay.off(); this._pay = null; } }
  _initPay() {
    this._killPay();
    const section = document.querySelector('[aria-label="Links principais"]');
    if (!section) return;
    const btns = [...section.querySelectorAll('.tm-pay-btn')];
    const copies = [...section.querySelectorAll('.tm-pay-copy')];
    // valores entram como texto (nunca como HTML)
    section.querySelectorAll('.tm-pay-val').forEach((el) => { el.textContent = el.getAttribute('data-v') || ''; });
    const onToggle = (e) => {
      const btn = e.currentTarget, open = btn.getAttribute('aria-expanded') !== 'true';
      btns.forEach((b) => {
        const on = b === btn && open;
        b.setAttribute('aria-expanded', on ? 'true' : 'false');
        const p = document.getElementById(b.getAttribute('aria-controls'));
        if (p) p.hidden = !on;
      });
    };
    const timers = new Map();
    const orig = new Map();
    const onCopy = async (e) => {
      const b = e.currentTarget, label = b.querySelector('.tm-pay-label'), text = b.getAttribute('data-copy') || '';
      if (!orig.has(b)) orig.set(b, label.textContent);
      let msg;
      if (!text || text.charAt(0) === '[') msg = 'AINDA NÃO INFORMADO';
      else {
        let ok = false;
        try { await navigator.clipboard.writeText(text); ok = true; } catch (err) {
          try {
            const ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', '');
            ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
            ok = document.execCommand('copy'); ta.remove();
          } catch (err2) { ok = false; }
        }
        msg = ok ? 'COPIADO ✓' : 'NÃO FOI POSSÍVEL COPIAR';
      }
      label.textContent = msg;
      clearTimeout(timers.get(b)); timers.set(b, setTimeout(() => { label.textContent = orig.get(b); }, 2400));
    };
    btns.forEach((b) => b.addEventListener('click', onToggle));
    copies.forEach((b) => b.addEventListener('click', onCopy));
    this._pay = { section, off: () => {
      btns.forEach((b) => b.removeEventListener('click', onToggle));
      copies.forEach((b) => b.removeEventListener('click', onCopy));
      timers.forEach((t) => clearTimeout(t));
    } };
  }
  // Avaliações: setas que passam os cards e se desativam nas pontas
  _killReviews() { if (this._rev) { this._rev.off(); this._rev = null; } if (this._ad) { this._ad.off(); this._ad = null; } }
  _initReviews() {
    this._killReviews();
    this._rev = this._carousel('avaliacoes');
    this._ad = this._carousel('antes-depois');
  }
  _carousel(id) {
    const section = document.getElementById(id);
    const track = section && section.querySelector('.tm-rev-track');
    const prev = section && section.querySelector('.tm-rev-prev');
    const next = section && section.querySelector('.tm-rev-next');
    if (!track || !prev || !next) return;
    const step = () => { const c = track.querySelector('.tm-rev-card'); return c ? c.getBoundingClientRect().width + 24 : track.clientWidth; };
    const update = () => {
      const max = track.scrollWidth - track.clientWidth - 8;
      prev.disabled = track.scrollLeft <= 8;
      next.disabled = track.scrollLeft >= max;
    };
    const goPrev = () => track.scrollBy({ left: -step() });
    const goNext = () => track.scrollBy({ left: step() });
    prev.addEventListener('click', goPrev); next.addEventListener('click', goNext);
    track.addEventListener('scroll', update, { passive: true }); window.addEventListener('resize', update);
    update(); setTimeout(update, 300);
    return { section, off: () => {
      prev.removeEventListener('click', goPrev); next.removeEventListener('click', goNext);
      track.removeEventListener('scroll', update); window.removeEventListener('resize', update);
    } };
  }
  // Local de atendimento: abas (setas do teclado) e botão de copiar endereço
  _killLocal() { if (this._local) { this._local.off(); this._local = null; } }
  _initLocal() {
    this._killLocal();
    const section = document.getElementById('localizacao');
    if (!section) return;
    const tabs = [...section.querySelectorAll('[role="tab"]')];
    const select = (i, focus) => {
      tabs.forEach((tab, j) => {
        const on = j === i;
        tab.setAttribute('aria-selected', on ? 'true' : 'false');
        tab.tabIndex = on ? 0 : -1;
        const panel = document.getElementById(tab.getAttribute('aria-controls'));
        if (panel) panel.hidden = !on;
      });
      if (focus) tabs[i].focus();
    };
    const onClick = (e) => { const i = tabs.indexOf(e.currentTarget); if (i >= 0) select(i, false); };
    const onKey = (e) => {
      const i = tabs.indexOf(e.currentTarget); const n = tabs.length;
      const next = { ArrowRight: (i + 1) % n, ArrowLeft: (i - 1 + n) % n, Home: 0, End: n - 1 }[e.key];
      if (next !== undefined) { e.preventDefault(); select(next, true); }
    };
    tabs.forEach((tab) => { tab.addEventListener('click', onClick); tab.addEventListener('keydown', onKey); });
    // horário: destaca hoje e indica se está aberto agora (fuso de São Paulo)
    try {
      const parts = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Sao_Paulo', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date());
      const get = (k) => (parts.find((p) => p.type === k) || {}).value;
      const day = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(get('weekday'));
      const mins = Number(get('hour')) * 60 + Number(get('minute'));
      const SCHEDULE = { 1: [510, 1080], 2: [510, 1080], 3: [510, 1080], 4: [510, 1080], 5: [510, 1080], 6: [510, 690] };
      section.querySelectorAll('.tm-hours-row').forEach((row) => {
        const today = (row.getAttribute('data-days') || '').split(',').map(Number).includes(day);
        row.classList.toggle('is-today', today);
        if (today) row.setAttribute('aria-current', 'date'); else row.removeAttribute('aria-current');
      });
      const badge = section.querySelector('.tm-open');
      if (badge && day >= 0) {
        const s = SCHEDULE[day]; const open = !!s && mins >= s[0] && mins < s[1];
        badge.textContent = open ? 'ABERTO AGORA' : 'FECHADO AGORA';
        badge.style.background = open ? '#8C6A35' : '#F6E4E3';
        badge.style.color = open ? '#FFFFFF' : '#7A4A4C';
        badge.hidden = false;
      }
    } catch (e) { /* sem Intl: mostra só a tabela */ }
    // galeria do consultório: miniaturas trocam a foto principal
    const main = section.querySelector('.tm-office-main');
    const count = section.querySelector('.tm-office-count');
    const thumbs = [...section.querySelectorAll('.tm-office-thumb')];
    const onThumb = (e) => {
      const btn = e.currentTarget; const i = thumbs.indexOf(btn);
      if (!main || i < 0) return;
      thumbs.forEach((b) => b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'));
      main.style.opacity = '0';
      setTimeout(() => { main.src = btn.getAttribute('data-src'); main.alt = btn.getAttribute('data-alt'); main.style.opacity = '1'; }, 150);
      if (count) count.textContent = (i + 1) + ' / ' + thumbs.length;
    };
    thumbs.forEach((b) => b.addEventListener('click', onThumb));
    // mapa real do Google (ruas, comércios e pontos próximos): carrega sozinho perto da tela só se a pessoa aceitou os cookies;
    // sem aceite, carrega quando ela toca no mapa.
    // se o ambiente bloquear o iframe (política de segurança), volta para a prévia desenhada + link.
    const map = section.querySelector('.tm-map');
    let frame = null, mapIO = null, blocked = false;
    const onCsp = (ev) => {
      if (!frame || !/frame-src|child-src|default-src/.test(ev.violatedDirective || ev.effectiveDirective || '')) return;
      blocked = true; frame.remove(); frame = null; if (map) map.style.visibility = '';
    };
    const loadMap = (focus) => {
      const src = map ? map.getAttribute('data-embed') || '' : '';
      if (frame || blocked || src.indexOf('https://www.google.com/maps?') !== 0) return false;
      frame = document.createElement('iframe');
      frame.src = src; frame.title = 'Mapa do consultório da Dra. Thábata Magatão em Campo Largo';
      frame.referrerPolicy = 'strict-origin-when-cross-origin'; frame.allowFullscreen = true;
      map.parentNode.appendChild(frame);
      frame.addEventListener('load', () => { if (frame && !blocked) { map.style.visibility = 'hidden'; map.tabIndex = -1; if (focus) frame.focus(); } }, { once: true });
      return true;
    };
    const onMap = (e) => {
      if (frame && !blocked) { e.preventDefault(); return; }
      if (!blocked && loadMap(true)) e.preventDefault();
    };
    const startAuto = () => {
      if (!map || mapIO || frame) return;
      if ('IntersectionObserver' in window) {
        mapIO = new IntersectionObserver((es) => { if (es[0].isIntersecting) { loadMap(false); mapIO.disconnect(); } }, { rootMargin: '400px 0px' });
        mapIO.observe(map);
      } else loadMap(false);
    };
    const onConsent = (e) => { if (e.detail === 'granted') startAuto(); };
    if (map) {
      document.addEventListener('securitypolicyviolation', onCsp);
      document.addEventListener('tm-consent', onConsent);
      map.addEventListener('click', onMap);
      if (this._consent() === 'granted') startAuto();
    }
    const btn = section.querySelector('.tm-copy');
    const label = btn && btn.querySelector('.tm-copy-label');
    const original = label ? label.textContent : '';
    let timer;
    const onCopy = async () => {
      const text = btn.getAttribute('data-copy') || '';
      let ok = false;
      try { await navigator.clipboard.writeText(text); ok = true; } catch (e) {
        try {
          const ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', '');
          ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
          ok = document.execCommand('copy'); ta.remove();
        } catch (e2) { ok = false; }
      }
      if (label) label.textContent = ok ? 'ENDEREÇO COPIADO ✓' : 'NÃO FOI POSSÍVEL COPIAR';
      clearTimeout(timer); timer = setTimeout(() => { if (label) label.textContent = original; }, 2400);
    };
    if (btn) btn.addEventListener('click', onCopy);
    this._local = { section, off: () => {
      tabs.forEach((tab) => { tab.removeEventListener('click', onClick); tab.removeEventListener('keydown', onKey); });
      if (btn) btn.removeEventListener('click', onCopy); clearTimeout(timer);
      if (map) map.removeEventListener('click', onMap);
      document.removeEventListener('securitypolicyviolation', onCsp); document.removeEventListener('tm-consent', onConsent); if (mapIO) mapIO.disconnect();
      thumbs.forEach((b) => b.removeEventListener('click', onThumb));
    } };
  }
  componentDidUpdate() {
    const sec = document.getElementById('procedimentos');
    if (this._gal && this._gal.section !== sec) this._initGallery();
    if (this._local && this._local.section !== document.getElementById('localizacao')) this._initLocal();
    if (this._rev && this._rev.section !== document.getElementById('avaliacoes')) this._initReviews();
    if (this._pay && this._pay.section !== document.querySelector('[aria-label="Links principais"]')) this._initPay();
    if (this._prof && this._prof.section !== document.getElementById('profissionais')) this._initProf();
    if (this._cookies && this._cookies.box !== document.querySelector('.tm-cookie')) this._initCookies();
  }
  componentWillUnmount() {
    this._killGallery(); this._killLocal(); this._killReviews(); this._killPay(); this._killProf(); this._killCookies();
    if (this._onResize) window.removeEventListener('resize', this._onResize);
  }
  _killGallery() {
    cancelAnimationFrame(this._raf); clearTimeout(this._retry);
    if (this._gal) { this._gal.ctx.revert(); this._gal = null; }
  }
  _initGallery() {
    this._killGallery();
    // fotos da galeria: não disputam com a foto do topo; baixam logo depois que a página termina de carregar,
    // para já estarem prontas (sem travar) quando a pessoa chegar na animação
    const warm = () => document.querySelectorAll('#procedimentos img[loading="lazy"]').forEach((img) => { img.loading = 'eager'; });
    if (document.readyState === 'complete') setTimeout(warm, 300); else window.addEventListener('load', () => setTimeout(warm, 300), { once: true });
    let tries = 0;
    const attempt = () => {
      const gsap = window.gsap, ST = window.ScrollTrigger;
      const section = document.getElementById('procedimentos');
      const inner = section && section.querySelector('.tm-gal-inner');
      const viewport = section && section.querySelector('.tm-gal-viewport');
      const track = section && section.querySelector('.tm-gal-track');
      const bar = section && section.querySelector('.tm-gal-progress');
      const ready = gsap && ST && inner && viewport && track && bar &&
        document.readyState !== 'loading' && track.scrollWidth > 0 && viewport.clientWidth > 0;
      if (!ready) { if (tries++ < 50) this._retry = setTimeout(attempt, 100); return; }
      if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      // descobre quem rola a página: a janela ou um contêiner com overflow (ex.: o visualizador do design)
      const findScroller = () => {
        for (let n = section.parentElement; n && n !== document.documentElement; n = n.parentElement) {
          const oy = getComputedStyle(n).overflowY;
          if (/(auto|scroll|overlay)/.test(oy) && n.scrollHeight > n.clientHeight + 1) return n;
        }
        const se = document.scrollingElement || document.documentElement;
        return se.scrollHeight > window.innerHeight + 1 ? window : null;
      };
      const scroller = findScroller();
      if (!scroller) return; // nada rola verticalmente aqui: fica o deslize com o dedo
      const viewH = () => (scroller === window ? window.innerHeight : scroller.clientHeight);
      const distance = () => Math.max(0, track.scrollWidth - viewport.clientWidth);
      if (distance() < 8) return; // tudo cabe na tela: não precisa travar
      // seção inteira cabe na tela: trava tudo (título + cards).
      // celular mais baixo: trava só os cards + barra (o título passa antes).
      // nem os cards cabem: não trava, fica o deslize com o dedo.
      const stage = section.querySelector('.tm-gal-stage') || viewport;
      const mode = () => (inner.offsetHeight <= viewH() + 1 ? 'inner' : (stage.offsetHeight <= viewH() + 1 ? 'stage' : 'none'));
      const fits = () => mode();
      if (!this._onResize) {
        this._onResize = () => {
          clearTimeout(this._rz);
          this._rz = setTimeout(() => { if (fits() !== this._fits) this._initGallery(); }, 250);
        };
        window.addEventListener('resize', this._onResize);
      }
      this._fits = fits();
      if (this._fits === 'none') return;
      const pinEl = this._fits === 'inner' ? inner : stage;
      const startAt = this._fits === 'inner' ? 'top top' : 'center center';
      gsap.registerPlugin(ST);
      // celular: a barra de endereço some/aparece ao rolar; não recalcular nisso evita trancos
      ST.config({ ignoreMobileResize: true });
      const ctx = gsap.context(() => {
        gsap.set(viewport, { overflow: 'hidden', scrollSnapType: 'none' });
        const tl = gsap.timeline({
          defaults: { ease: 'none' },
          scrollTrigger: {
            trigger: pinEl, scroller, start: startAt, end: () => '+=' + distance(),
            pin: pinEl, pinSpacing: true, scrub: 0.6, anticipatePin: 1, invalidateOnRefresh: true,
          },
        });
        tl.to(track, { x: () => -distance(), force3D: true }, 0).fromTo(bar, { scaleX: 0 }, { scaleX: 1 }, 0);
      }, section);
      this._gal = { ctx, section };
      // recalcula quando fontes e imagens terminarem de carregar
      const refresh = () => { if (this._gal) ST.refresh(); };
      if (document.fonts && document.fonts.ready) document.fonts.ready.then(refresh);
      section.querySelectorAll('img').forEach((img) => { if (!img.complete) img.addEventListener('load', refresh, { once: true }); });
      if (document.readyState !== 'complete') window.addEventListener('load', refresh, { once: true });
      this._gal.scroller = scroller;
    };
    this._raf = requestAnimationFrame(() => {
      this._raf = requestAnimationFrame(() => { this._retry = setTimeout(attempt, 150); });
    });
  }
  renderVals() {
    // Valores padrão (dados públicos do cartão de visita)
    const D_NUM = '5542999827626', D_IG = 'dra.thabatamagatao';
    const D_END = 'Av. Desembargador Clotário Portugal, 75 - Centro, Campo Largo - PR';
    const D_GOOGLE = 'https://search.google.com/local/writereview?placeid=ChIJCYs2m4cZ3ZQROeK4dngLa6Y'; // abre direto a tela de avaliar no Google
    // WhatsApp: só dígitos, 10 a 15 (padrão E.164); senão usa o padrão
    let num = String(this.props.whatsapp ?? D_NUM).replace(/\D/g, '');
    if (!/^\d{10,15}$/.test(num)) num = D_NUM;
    // Instagram: só caracteres válidos de @ (letras, números, ponto, _), até 30
    let ig = String(this.props.instagramUser ?? D_IG).trim().replace(/^@/, '');
    if (!/^[A-Za-z0-9._]{1,30}$/.test(ig)) ig = D_IG;
    // Endereço: texto livre, sempre codificado na URL, limitado a 200 caracteres
    const end = (String(this.props.endereco ?? D_END).trim().slice(0, 200)) || D_END;
    // Link de avaliações: só https e só domínios do Google
    const GOOGLE_HOSTS = ['share.google', 'g.page', 'goo.gl', 'maps.app.goo.gl', 'google.com', 'www.google.com', 'search.google.com', 'maps.google.com', 'business.google.com'];
    const safeGoogle = (raw) => {
      try {
        const u = new URL(String(raw ?? '').trim());
        if (u.protocol !== 'https:' || u.username || u.password) return null;
        const h = u.hostname.toLowerCase();
        if (!GOOGLE_HOSTS.includes(h) && !h.endsWith('.google.com')) return null;
        return u.href;
      } catch (e) { return null; }
    };
    // Pix e Wi-Fi: texto livre, sem controle/quebra de linha, com limite de tamanho; vazio = placeholder
    const clean = (v, max) => String(v ?? '').replace(/[\u0000-\u001F\u007F]/g, '').trim().slice(0, max);
    const pix = clean(this.props.pixChave, 77) || '44.034.111/0001-94';
    // CNPJ: copia só os números (aceito por todos os bancos)
    const pixCopia = /^\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}$/.test(pix) ? pix.replace(/\D/g, '') : pix;
    const wifiRede = clean(this.props.wifiRede, 32) || 'Brolex alunos';
    const wifiSenha = clean(this.props.wifiSenha, 63);
    const wa = (msg) => 'https://wa.me/' + num + '?text=' + encodeURIComponent(msg);
    const sobre = (p) => wa('Olá, Dra. Thábata! Gostaria de saber mais sobre ' + p + '.');
    return {
      waBotox: sobre('toxina botulínica (Botox)'),
      waHarmFacial: sobre('harmonização facial'),
      waBio: sobre('bioestimulador de colágeno'),
      waLimpeza: sobre('limpeza de pele'),
      waMicro: sobre('microagulhamento'),
      waOrelha: sobre('harmonização de orelhas'),
      whatsAgendar: wa('Olá, Dra. Thábata! Gostaria de agendar uma avaliação.'),
      whatsContato: wa('Olá! Tenho uma dúvida e gostaria de falar com a equipe.'),
      instagram: 'https://www.instagram.com/' + ig + '/',
      maps: 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(end),
      waze: 'https://waze.com/ul?q=' + encodeURIComponent(end) + '&navigate=yes',
      mapsEmbed: 'https://www.google.com/maps?q=' + encodeURIComponent(end) + '&z=17&output=embed',
      pixChave: pix, pixCopia: pixCopia, wifiRede: wifiRede,
      wifiSenha: wifiSenha || 'Rede aberta, não precisa de senha', wifiCopia: wifiRede,
      google: safeGoogle(this.props.googleAvaliacoes) || D_GOOGLE
    };
  }
}

  const c = new Component();
  const start = () => c.componentDidMount();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
